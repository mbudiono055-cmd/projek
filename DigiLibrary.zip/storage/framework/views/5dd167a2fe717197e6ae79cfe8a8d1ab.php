<?php $__env->startSection('content'); ?>

<div class="max-w-7xl mx-auto px-4">

    <!-- Header -->
    <div class="mb-8">
        <h2 class="text-3xl font-extrabold text-slate-800">
            📚 Katalog Buku
        </h2>
        <p class="text-slate-500 mt-1">
            Temukan dan pinjam buku favoritmu dengan mudah.
        </p>
    </div>

    <!-- ================= FILTER & SEARCH ================= -->
    <div class="mb-8">
        <form method="GET" action="<?php echo e(route('siswa.katalog')); ?>">

            <div class="flex flex-col lg:flex-row gap-3 w-full">

                <!-- Search Judul (FULL LEBAR) -->
                <input type="text"
                       name="search"
                       value="<?php echo e(request('search')); ?>"
                       placeholder="Cari judul buku..."
                       class="flex-1 w-full px-4 py-3 rounded-xl border border-slate-300
                              focus:ring-2 focus:ring-indigo-500 focus:outline-none">

                <!-- Filter Kategori -->
                <select name="kategori"
                        class="w-full lg:w-60 px-4 py-3 rounded-xl border border-slate-300
                               focus:ring-2 focus:ring-indigo-500 focus:outline-none">

                    <option value="">Semua Kategori</option>

                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($kat->id); ?>"
                            <?php echo e(request('kategori') == $kat->id ? 'selected' : ''); ?>>
                            <?php echo e($kat->nama_kategori); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <!-- Button -->
                <button type="submit"
                        class="px-6 py-3 rounded-xl bg-indigo-600 text-white font-semibold
                               hover:bg-indigo-700 transition whitespace-nowrap">
                    Cari
                </button>

                <?php if(request('search') || request('kategori')): ?>
                    <a href="<?php echo e(route('siswa.katalog')); ?>"
                       class="px-5 py-3 rounded-xl bg-slate-200 text-slate-700
                              hover:bg-slate-300 transition whitespace-nowrap text-center">
                        Reset
                    </a>
                <?php endif; ?>

            </div>

        </form>
    </div>

    <!-- ================= GRID BUKU ================= -->
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">

        <?php $__empty_1 = true; $__currentLoopData = $bukus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="bg-white rounded-2xl shadow-md hover:shadow-xl transition duration-300 overflow-hidden border border-slate-100 hover:-translate-y-1">

            <!-- Gambar -->
            <div class="bg-slate-50 p-4">
                <img src="<?php echo e(asset('storage/' . $item->gambar)); ?>"
                     class="w-full h-72 object-contain">
            </div>

            <!-- Content -->
            <div class="p-6">

                <h3 class="text-lg font-bold text-slate-800 mb-2 line-clamp-2">
                    <?php echo e($item->judul); ?>

                </h3>

                <span class="inline-block text-xs font-semibold px-3 py-1 rounded-full bg-indigo-100 text-indigo-700 mb-3">
                    <?php echo e($item->kategori->nama_kategori ?? '-'); ?>

                </span>

                <div class="space-y-1 text-sm text-slate-600 mb-4">
                    <p><span class="font-medium">Pengarang:</span> <?php echo e($item->pengarang); ?></p>
                    <p><span class="font-medium">Penerbit:</span> <?php echo e($item->penerbit); ?></p>
                    <p><span class="font-medium">Tahun:</span> <?php echo e($item->tahun_terbit); ?></p>
                </div>

                <div class="mb-4">
                    <?php if($item->stok > 0): ?>
                        <span class="text-sm font-semibold text-emerald-600">
                            Stok tersedia (<?php echo e($item->stok); ?>)
                        </span>
                    <?php else: ?>
                        <span class="text-sm font-semibold text-rose-600">
                            Stok habis
                        </span>
                    <?php endif; ?>
                </div>

                <a href="<?php echo e(route('siswa.detail', $item->id)); ?>"
                   class="block w-full text-center py-2.5 rounded-xl font-semibold text-white
                          bg-gradient-to-r from-indigo-600 to-blue-600
                          hover:from-indigo-700 hover:to-blue-700
                          transition duration-300 shadow-md">
                    Lihat Detail
                </a>

            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <div class="col-span-3 text-center text-slate-400 py-12">
                Buku tidak ditemukan 📖
            </div>
        <?php endif; ?>

    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.siswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\perpus-digital\resources\views/siswa/katalog.blade.php ENDPATH**/ ?>