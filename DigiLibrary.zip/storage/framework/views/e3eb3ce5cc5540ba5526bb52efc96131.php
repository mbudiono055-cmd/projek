<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto mt-10">

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-700 p-4 rounded-xl mb-6">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="bg-white rounded-2xl shadow-xl p-8 text-center">

        <!-- Foto -->
        <div class="mb-6">
            <?php if(isset($admin) && $admin->foto): ?>
    <img src="<?php echo e(asset('foto_admin/' . $admin->foto)); ?>"
         class="w-32 h-32 rounded-full mx-auto object-cover shadow-lg">
<?php else: ?>
    <img src="https://ui-avatars.com/api/?name=<?php echo e($admin->nama ?? 'Admin'); ?>"
         class="w-32 h-32 rounded-full mx-auto shadow-lg">
<?php endif; ?>
        </div>

        <?php if($admin): ?>
            <h2 class="text-2xl font-bold"><?php echo e($admin->nama); ?></h2>
            <p class="text-gray-500 mb-6"><?php echo e($admin->email); ?></p>
        <?php else: ?>
            <p class="text-red-500">Data admin tidak ditemukan</p>
        <?php endif; ?>

        <a href="<?php echo e(route('profil.edit')); ?>"
           class="bg-blue-600 text-white px-6 py-3 rounded-xl hover:bg-blue-700 transition">
            Edit Profil
        </a>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\perpus-digital\resources\views/admin/profil/index.blade.php ENDPATH**/ ?>