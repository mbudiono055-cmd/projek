<?php $__env->startSection('content'); ?>

<div class="mb-8">
    <h2 class="text-3xl font-bold text-gray-800">📚 Buku Saya</h2>
    <p class="text-gray-500 mt-1">Daftar buku yang sedang atau pernah kamu pinjam</p>
</div>

<div class="bg-white shadow-xl rounded-2xl overflow-hidden">

    <div class="overflow-x-auto">
        <table class="w-full text-sm text-left">

            <thead class="bg-gradient-to-r from-blue-600 to-indigo-600 text-white">
                <tr>
                    <th class="p-4 font-semibold">Judul Buku</th>
                    <th class="p-4 font-semibold">Tanggal Pinjam</th>
                    <th class="p-4 font-semibold">Tanggal Kembali</th>
                    <th class="p-4 font-semibold text-center">Status</th>
                </tr>
            </thead>

            <tbody class="divide-y divide-gray-100">

            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50 transition duration-200">

                    <td class="p-4 font-medium text-gray-800">
                        <?php echo e($item->buku->judul); ?>

                    </td>

                    <td class="p-4 text-gray-600">
                        <?php echo e(\Carbon\Carbon::parse($item->tanggal_pinjam)->format('d M Y')); ?>

                    </td>

                    <td class="p-4 text-gray-600">
                        <?php echo e(\Carbon\Carbon::parse($item->tanggal_kembali)->format('d M Y')); ?>

                    </td>

                    <td class="p-4 text-center">
                        <?php if($item->status == 'diterima'): ?>
                            <span class="px-3 py-1 text-xs font-semibold bg-yellow-100 text-yellow-700 rounded-full">
                                Dipinjam
                            </span>
                        <?php elseif($item->status == 'terlambat'): ?>
                            <span class="px-3 py-1 text-xs font-semibold bg-red-100 text-red-700 rounded-full">
                                Terlambat
                            </span>
                        <?php elseif($item->status == 'dikembalikan'): ?>
                            <span class="px-3 py-1 text-xs font-semibold bg-green-100 text-green-700 rounded-full">
                                Dikembalikan
                            </span>
                        <?php else: ?>
                            <span class="px-3 py-1 text-xs font-semibold bg-gray-100 text-gray-700 rounded-full">
                                <?php echo e(ucfirst($item->status)); ?>

                            </span>
                        <?php endif; ?>
                    </td>

                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="p-6 text-center text-gray-500">
                        Belum ada buku yang dipinjam 📖
                    </td>
                </tr>
            <?php endif; ?>

            </tbody>
        </table>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.siswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\perpus-digital\resources\views/siswa/buku_saya.blade.php ENDPATH**/ ?>