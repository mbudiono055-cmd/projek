<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto mt-10">

    <h1 class="text-3xl font-bold mb-6">Profil Admin</h1>

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-700 p-4 rounded-xl mb-6">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="bg-white rounded-2xl shadow-lg p-8">

        <form action="<?php echo e(route('admin.profil.update')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <!-- Nama -->
            <div class="mb-6">
                <label class="block text-gray-700 font-semibold mb-2">
                    Nama
                </label>
                <input type="text"
                       name="nama"
                       value="<?php echo e(old('nama', $admin->nama ?? '')); ?>"
                       class="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
            </div>

            <!-- Email -->
            <div class="mb-6">
                <label class="block text-gray-700 font-semibold mb-2">
                    Email
                </label>
                <input type="email"
                       name="email"
                       value="<?php echo e(old('email', $admin->email ?? '')); ?>"
                       class="w-full px-4 py-3 rounded-xl border border-gray-300 focus:ring-2 focus:ring-blue-500 focus:outline-none">
            </div>

            <button type="submit"
                    class="bg-blue-600 text-white px-6 py-3 rounded-xl hover:bg-blue-700 transition">
                Update Profil
            </button>

        </form>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\perpus-digital\resources\views/admin/profil.blade.php ENDPATH**/ ?>