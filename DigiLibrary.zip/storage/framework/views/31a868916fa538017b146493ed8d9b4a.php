<?php $__env->startSection('content'); ?>

<div class="max-w-xl mx-auto">
    <div class="bg-white shadow-lg rounded-xl p-8">

        <h2 class="text-2xl font-bold mb-6">
            Edit Petugas
        </h2>

        <form action="<?php echo e(route('petugas.update', $petugas->id)); ?>" method="POST" class="space-y-5">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div>
                <label class="block mb-2 font-semibold">Nama</label>
                <input type="text" name="nama"
                    value="<?php echo e($petugas->nama); ?>"
                    class="w-full border rounded px-4 py-2">
            </div>

            <div>
                <label class="block mb-2 font-semibold">Email</label>
                <input type="email" name="email"
                    value="<?php echo e($petugas->email); ?>"
                    class="w-full border rounded px-4 py-2">
            </div>

            <div>
                <label class="block mb-2 font-semibold">Password</label>
                <input type="password" name="password"
                    placeholder="Kosongkan jika tidak ingin mengubah password"
                    class="w-full border rounded px-4 py-2">
            </div>

            <div class="flex justify-between pt-4">
                <a href="<?php echo e(route('petugas.index')); ?>"
                   class="bg-gray-400 text-white px-5 py-2 rounded-lg">
                    Kembali
                </a>

                <button type="submit"
                    class="bg-yellow-500 text-white px-6 py-2 rounded-lg">
                    Update
                </button>
            </div>

        </form>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\perpus-digital\resources\views/admin/petugas/edit.blade.php ENDPATH**/ ?>