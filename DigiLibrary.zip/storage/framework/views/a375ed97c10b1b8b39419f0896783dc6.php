<?php $__env->startSection('content'); ?>

<h2 class="text-2xl font-bold mb-6">Tambah Buku</h2>

<form action="<?php echo e(route('buku.store')); ?>"
      method="POST"
      enctype="multipart/form-data"
      class="bg-white p-6 rounded shadow">

    <?php echo csrf_field(); ?>

    <div class="mb-4">
        <label class="block mb-1">Judul</label>
        <input type="text" name="judul" class="w-full border p-2 rounded">
    </div>

    <div class="mb-4">
        <label class="block mb-1">Pengarang</label>
        <input type="text" name="pengarang" class="w-full border p-2 rounded">
    </div>

    <div class="mb-4">
        <label class="block mb-1">Penerbit</label>
        <input type="text" name="penerbit" class="w-full border p-2 rounded">
    </div>

    <div class="mb-4">
        <label class="block mb-1">Kategori</label>
        <select name="kategori_id" class="w-full border p-2 rounded">
            <option value="">-- Pilih Kategori --</option>
            <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($k->id); ?>">
                    <?php echo e($k->nama_kategori); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="mb-4">
        <label class="block mb-1">Tahun Terbit</label>
        <input type="number" name="tahun_terbit" class="w-full border p-2 rounded">
    </div>

    <div class="mb-4">
        <label class="block mb-1">Stok</label>
        <input type="number" name="stok" class="w-full border p-2 rounded">
    </div>

    <div class="mb-4">
        <label class="block mb-1">Gambar</label>
        <input type="file" name="gambar" class="w-full border p-2 rounded">
    </div>

    <button class="bg-blue-600 text-white px-4 py-2 rounded">
        Simpan
    </button>

    <a href="<?php echo e(route('buku.index')); ?>"
           class="bg-gray-400 text-white px-6 py-2 rounded-lg">
            Kembali
        </a>

</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\perpus-digital\resources\views/admin/buku/create.blade.php ENDPATH**/ ?>