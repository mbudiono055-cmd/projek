<?php $__env->startSection('content'); ?>

<div class="max-w-xl mx-auto bg-white p-6 rounded-lg shadow">

    <h2 class="text-xl font-bold mb-4">Tambah Kategori</h2>

    <form action="<?php echo e(route('kategori.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <div class="mb-4">
        <label>Nama Kategori</label>
        <input type="text" name="nama_kategori"
               class="border p-2 w-full" required>
    </div>

    <button type="submit"
            class="bg-blue-600 text-white px-4 py-2 rounded">
        Simpan
    </button>
</form>


</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\perpus-digital\resources\views/admin/kategori/create.blade.php ENDPATH**/ ?>