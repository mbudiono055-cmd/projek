<?php $__env->startSection('content'); ?>

<h2 class="text-2xl font-bold mb-6 text-slate-800">
    Riwayat Peminjaman
</h2>

<div class="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">

    <div class="overflow-x-auto">
        <table class="w-full text-sm">
            <thead class="bg-blue-600 text-white uppercase text-xs tracking-wider">
                <tr>
                    <th class="px-6 py-4 text-center">No</th>
                    <th class="px-6 py-4 text-left">User</th>
                    <th class="px-6 py-4 text-left">Buku</th>
                    <th class="px-6 py-4 text-center">Jumlah</th>
                    <th class="px-6 py-4 text-center">Tanggal Pinjam</th>
                    <th class="px-6 py-4 text-center">Tanggal Kembali</th>
                    <th class="px-6 py-4 text-center">Status</th>
                </tr>
            </thead>

            <tbody class="divide-y divide-slate-100">
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-slate-50 transition duration-200">

                    <td class="px-6 py-4 text-center font-semibold text-slate-600">
                        <?php echo e($loop->iteration); ?>

                    </td>

                    <td class="px-6 py-4 font-medium text-slate-700">
                        <?php echo e($item->user->nama ?? '-'); ?>

                    </td>

                    <td class="px-6 py-4 text-slate-600">
                        <?php echo e($item->buku->judul); ?>

                    </td>

                    <td class="px-6 py-4 text-center">
                        <span class="px-2 py-1 bg-slate-100 rounded-md text-xs font-semibold">
                            <?php echo e($item->jumlah); ?>

                        </span>
                    </td>

                    <td class="px-6 py-4 text-center text-slate-500">
                        <?php echo e($item->tanggal_pinjam->format('d M Y')); ?>

                    </td>

                    <td class="px-6 py-4 text-center text-slate-500">
                        <?php echo e($item->tanggal_kembali->format('d M Y')); ?>

                    </td>

                    <td class="px-6 py-4 text-center">
                        <?php if($item->status == 'menunggu'): ?>
                            <span class="px-3 py-1 text-xs font-semibold rounded-full bg-yellow-100 text-yellow-700">
                                Menunggu
                            </span>
                        <?php elseif($item->status == 'diterima'): ?>
                            <span class="px-3 py-1 text-xs font-semibold rounded-full bg-emerald-100 text-emerald-700">
                                Disetujui
                            </span>
                        <?php elseif($item->status == 'ditolak'): ?>
                            <span class="px-3 py-1 text-xs font-semibold rounded-full bg-rose-100 text-rose-700">
                                Ditolak
                            </span>
                        <?php elseif($item->status == 'terlambat'): ?>
                            <span class="px-3 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-700">
                                Terlambat
                            </span>
                        <?php else: ?>
                            <span class="px-3 py-1 text-xs font-semibold rounded-full bg-blue-100 text-blue-700">
                                Dikembalikan
                            </span>
                        <?php endif; ?>
                    </td>

                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="px-6 py-10 text-center text-slate-400">
                        Belum ada data peminjaman 📚
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\perpus-digital\resources\views/admin/peminjaman/index.blade.php ENDPATH**/ ?>