<?php $__env->startSection('content'); ?>
<div class="max-w-3xl mx-auto mt-10">

    <div class="bg-white rounded-2xl shadow-xl p-8">

        <form action="<?php echo e(route('profil.update')); ?>"
              method="POST"
              enctype="multipart/form-data"
              class="space-y-6">

            <?php echo csrf_field(); ?>

            <!-- Foto -->
            <div class="mb-6">
                <label class="block mb-2 font-semibold">Foto Profil</label>
                <input type="file" name="foto"
                       class="w-full border p-3 rounded-xl">
            </div>

            <!-- Nama -->
            <div class="mb-6">
                <label class="block mb-2 font-semibold">Nama</label>
                <input type="text"
                       name="nama"
                       value="<?php echo e($admin->nama); ?>"
                       class="w-full border p-3 rounded-xl">
            </div>

            <!-- Email -->
            <div class="mb-6">
                <label class="block mb-2 font-semibold">Email</label>
                <input type="email"
                       name="email"
                       value="<?php echo e($admin->email); ?>"
                       class="w-full border p-3 rounded-xl">
            </div>

            <!-- Password -->
            <div class="mb-6">
                <label class="block mb-2 font-semibold">
                    Password Baru (Opsional)
                </label>
                <input type="password"
                       name="password"
                       class="w-full border p-3 rounded-xl">
            </div>

            <!-- Konfirmasi Password -->
            <div class="mb-6">
                <label class="block mb-2 font-semibold">
                    Konfirmasi Password
                </label>
                <input type="password"
                       name="password_confirmation"
                       class="w-full border p-3 rounded-xl">
            </div>

            <button type="submit"
                    class="bg-blue-600 text-white px-6 py-3 rounded-xl hover:bg-blue-700 transition">
                Simpan Perubahan
            </button>

            <a href="<?php echo e(route('profil')); ?>"
                   class="bg-gray-600 hover:bg-gray-600 text-white px-6 py-3 rounded-xl transition">
                    Kembali
                </a>

        </form>

    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\perpus-digital\resources\views/admin/profil/edit.blade.php ENDPATH**/ ?>