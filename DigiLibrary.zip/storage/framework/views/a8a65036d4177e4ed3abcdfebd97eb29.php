<?php $__env->startSection('content'); ?>

<div class="max-w-7xl mx-auto">

    <div class="flex justify-between items-center mb-6">
        <h2 class="text-3xl font-bold text-gray-800">📚 Data Buku</h2>

        <a href="<?php echo e(route('petugas.buku.create')); ?>"
           class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg shadow transition">
            + Tambah Buku
        </a>
    </div>

    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-300 text-green-700 px-4 py-3 rounded-lg mb-5">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
        <table class="min-w-full text-sm text-gray-700">
            <thead class="bg-blue-600 text-white uppercase text-xs">
                <tr>
                    <th class="px-6 py-4 text-left">No</th>
                    <th class="px-6 py-4 text-left">Gambar</th>
                    <th class="px-6 py-4 text-left">Judul</th>
                    <th class="px-6 py-4 text-left">Kategori</th>
                    <th class="px-6 py-4 text-left">Tahun</th>
                    <th class="px-6 py-4 text-left">Stok</th>
                    <th class="px-6 py-4 text-center">Aksi</th>
                </tr>
            </thead>

            <tbody class="divide-y">
                <?php $__currentLoopData = $buku; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-6 py-4"><?php echo e($loop->iteration); ?></td>

                    <td class="px-6 py-4">
                        <?php if($item->gambar): ?>
                            <img src="<?php echo e(asset('storage/'.$item->gambar)); ?>"
                                 class="w-14 h-20 object-cover rounded shadow">
                        <?php else: ?>
                            <span class="text-gray-400 italic">Tidak ada</span>
                        <?php endif; ?>
                    </td>

                    <td class="px-6 py-4 font-semibold"><?php echo e($item->judul); ?></td>
                    <td class="px-6 py-4"><?php echo e($item->kategori->nama_kategori ?? '-'); ?></td>
                    <td class="px-6 py-4"><?php echo e($item->tahun_terbit); ?></td>
                    <td class="px-6 py-4">
                        <span class="bg-blue-100 text-blue-600 px-3 py-1 rounded-full text-xs">
                            <?php echo e($item->stok); ?>

                        </span>
                    </td>

                    <td class="px-6 py-4 text-center space-x-2">
                        <a href="<?php echo e(route('petugas.buku.edit', $item->id)); ?>"
                           class="bg-yellow-400 hover:bg-yellow-500 text-white px-4 py-1 rounded-lg transition">
                            Edit
                        </a>

                        <form action="<?php echo e(route('petugas.buku.destroy', $item->id)); ?>"
                              method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button onclick="return confirm('Yakin hapus buku ini?')"
                                class="bg-red-500 hover:bg-red-600 text-white px-4 py-1 rounded-lg transition">
                                Hapus
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.petugas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\perpus-digital\resources\views/petugas/buku/index.blade.php ENDPATH**/ ?>