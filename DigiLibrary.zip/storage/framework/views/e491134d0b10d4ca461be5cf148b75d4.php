<?php $__env->startSection('content'); ?>

<div class="max-w-7xl mx-auto">

    <div class="flex justify-between items-center mb-6">
        <h2 class="text-3xl font-bold text-gray-800">📂 Data Kategori</h2>

        <a href="<?php echo e(route('kategori.create')); ?>"
           class="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2 rounded-lg shadow transition">
            + Tambah Kategori
        </a>
    </div>

    <div class="bg-white rounded-2xl shadow-lg overflow-hidden">
        <table class="min-w-full text-sm text-gray-700">
            <thead class="bg-blue-600 text-white uppercase text-xs">
                <tr>
                    <th class="px-6 py-4 text-left">No</th>
                    <th class="px-6 py-4 text-left">Nama Kategori</th>
                    <th class="px-6 py-4 text-center">Aksi</th>
                </tr>
            </thead>

            <tbody class="divide-y">
                <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-50 transition">
                    <td class="px-6 py-4"><?php echo e($loop->iteration); ?></td>
                    <td class="px-6 py-4 font-semibold text-gray-800">
                        <?php echo e($k->nama_kategori); ?>

                    </td>
                    <td class="px-6 py-4 text-center space-x-2">
                        <a href="<?php echo e(route('kategori.edit',$k->id)); ?>"
                           class="bg-yellow-400 hover:bg-yellow-500 text-white px-4 py-1 rounded-lg transition">
                            Edit
                        </a>

                        <form action="<?php echo e(route('kategori.destroy',$k->id)); ?>"
                              method="POST" class="inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button onclick="return confirm('Yakin hapus kategori ini?')"
                                class="bg-red-500 hover:bg-red-600 text-white px-4 py-1 rounded-lg transition">
                                Hapus
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="text-center py-8 text-gray-400">
                        Belum ada data kategori
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\perpus-digital\resources\views/admin/kategori/index.blade.php ENDPATH**/ ?>