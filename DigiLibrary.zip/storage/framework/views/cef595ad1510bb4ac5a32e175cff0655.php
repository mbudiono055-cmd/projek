<?php $__env->startSection('content'); ?>

<div class="min-h-screen flex items-center justify-center">
    <div class="w-full max-w-2xl bg-white p-10 rounded-2xl shadow-xl">

        <h2 class="text-3xl font-bold text-center text-gray-800 mb-8">
            ✏️ Edit Buku
        </h2>

        <form action="<?php echo e(route('buku.update', $buku->id)); ?>"
              method="POST"
              enctype="multipart/form-data"
              class="space-y-6">

            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <div>
                <label class="block text-sm font-semibold mb-2">Judul</label>
                <input type="text" name="judul"
                       value="<?php echo e($buku->judul); ?>"
                       class="w-full border rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500 focus:outline-none">
            </div>

            <div>
                <label class="block text-sm font-semibold mb-2">Pengarang</label>
                <input type="text" name="pengarang"
                       value="<?php echo e($buku->pengarang); ?>"
                       class="w-full border rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500">
            </div>

            <div>
                <label class="block text-sm font-semibold mb-2">Penerbit</label>
                <input type="text" name="penerbit"
                       value="<?php echo e($buku->penerbit); ?>"
                       class="w-full border rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500">
            </div>

            <div>
                <label class="block text-sm font-semibold mb-2">Kategori</label>
                <select name="kategori_id"
                        class="w-full border rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500">
                    <?php $__currentLoopData = $kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($k->id); ?>"
                            <?php echo e($buku->kategori_id == $k->id ? 'selected' : ''); ?>>
                            <?php echo e($k->nama_kategori); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <label class="block text-sm font-semibold mb-2">Tahun Terbit</label>
                <input type="number" name="tahun_terbit"
                       value="<?php echo e($buku->tahun_terbit); ?>"
                       class="w-full border rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500">
            </div>

            <div>
                <label class="block text-sm font-semibold mb-2">Stok</label>
                <input type="number" name="stok"
                       value="<?php echo e($buku->stok); ?>"
                       class="w-full border rounded-lg px-4 py-3 focus:ring-2 focus:ring-blue-500">
            </div>

            <div>
                <label class="block text-sm font-semibold mb-2">Gambar</label>
                <input type="file" name="gambar"
                       class="w-full border rounded-lg px-4 py-2">

                <?php if($buku->gambar): ?>
                    <div class="mt-4">
                        <p class="text-sm text-gray-500 mb-2">Preview Gambar:</p>
                        <img src="<?php echo e(asset('storage/'.$buku->gambar)); ?>"
                             class="w-24 rounded-lg shadow">
                    </div>
                <?php endif; ?>
            </div>

            <div class="flex justify-between pt-6">
                <a href="<?php echo e(route('buku.index')); ?>"
                   class="bg-gray-400 hover:bg-gray-500 text-white px-6 py-2 rounded-lg transition">
                    Kembali
                </a>

                <button class="bg-blue-600 hover:bg-blue-700 text-white px-8 py-2 rounded-lg shadow transition">
                    Update Buku
                </button>
            </div>

        </form>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.petugas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\perpus-digital\resources\views/petugas/buku/edit.blade.php ENDPATH**/ ?>